import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

import diagram_host
import diagram_orchestrator
import diagram_supervisor as supervisor


def clean_diagram():
    return """<?xml version="1.0" encoding="UTF-8"?>
<mxfile host="app.diagrams.net">
  <diagram id="page-1" name="Page-1"><mxGraphModel><root>
    <mxCell id="0"/><mxCell id="1" parent="0"/>
    <mxCell id="node" value="Step" parent="1" vertex="1">
      <mxGeometry x="100" y="100" width="160" height="60" as="geometry"/>
    </mxCell>
  </root></mxGraphModel></diagram>
</mxfile>
"""


def successful_reviewer(role, input_path, output_path, **kwargs):
    audit = supervisor.load_json(input_path)
    analysis = {
        "schema_version": 2,
        "role": "reviewer",
        "status": "ok",
        "analysis_id": "audit-analysis",
        "verdict": "approve",
        "reviewed_at": "2026-07-20T12:00:00+00:00",
        "findings": [],
    }
    supervisor.write_json(output_path, analysis)
    return {
        "resolution": {
            "requested_model": "vllm/DeepSeek-V4-Flash-262k",
            "resolved_model": "vllm/DeepSeek-V4-Flash-262k",
            "resolution_mode": "isolated_cli",
            "fallback_used": False,
            "provider": "vllm",
        },
        "runtime_metadata": {
            "reported_model": "vllm/DeepSeek-V4-Flash-262k",
            "model_proof": {
                "verified": True,
                "system_model": "vllm/DeepSeek-V4-Flash-262k",
                "assistant_model": "vllm/DeepSeek-V4-Flash-262k",
                "stats_models": ["vllm/DeepSeek-V4-Flash-262k"],
            },
            "isolation_proof": {
                "verified": True,
                "tool_calls": 0,
                "system_models": ["vllm/DeepSeek-V4-Flash-262k"],
                "assistant_models": ["vllm/DeepSeek-V4-Flash-262k"],
            },
        },
    }


class DiagramHostTests(unittest.TestCase):
    def test_review_command_owns_the_complete_read_only_workflow(self):
        with tempfile.TemporaryDirectory() as temp:
            workspace = Path(temp)
            artifact = workspace / "diagram.drawio"
            artifact.write_text(clean_diagram(), encoding="utf-8")
            original = hashlib.sha256(artifact.read_bytes()).hexdigest()

            with mock.patch.object(diagram_host.agent_runtime, "invoke_role", side_effect=successful_reviewer):
                result = diagram_host.run_review(
                    artifact, workspace, sys.executable, run_id="review-test"
                )

            run_dir = workspace / ".diagram-runs" / "review-test"
            self.assertEqual(result["status"], "passed")
            self.assertEqual(result["reviewer"]["status"], "completed")
            self.assertEqual(result["reviewer"]["resolved_model"], "vllm/DeepSeek-V4-Flash-262k")
            self.assertTrue(result["reviewer"]["model_proof"]["verified"])
            self.assertTrue(result["reviewer"]["binding_proof"]["verified"])
            self.assertEqual(result["reviewer"]["binding_proof"]["source"], "host-bound-reviewer-verdict-v2")
            self.assertEqual(result["mode"], "review")
            self.assertEqual(
                result["improve_handoff"]["artifact_sha256"], original
            )
            self.assertFalse(result["artifact"]["modified"])
            self.assertEqual(hashlib.sha256(artifact.read_bytes()).hexdigest(), original)
            self.assertTrue(supervisor.verify_host_preflight(run_dir)["valid"])
            self.assertEqual(supervisor.load_state(run_dir)["state"], "final_review")
            self.assertEqual(supervisor.load_json(run_dir / "host-result.json"), result)
            workflow = supervisor.load_json(run_dir / "workflow.json")
            self.assertEqual(workflow["mode"], "review")
            self.assertEqual(workflow["accepted_artifact"]["sha256"], original)
            self.assertEqual(
                result["evidence"]["workflow"], str((run_dir / "workflow.json").resolve())
            )
            analysis = supervisor.load_json(result["reviewer"]["analysis"])
            self.assertEqual(analysis["schema_version"], 2)
            self.assertEqual(analysis["analysis_id"], "audit-analysis")
            verdict = supervisor.load_json(result["reviewer"]["output"])
            self.assertEqual(verdict["schema_version"], 2)
            self.assertEqual(verdict["analysis_id"], "audit-analysis")
            self.assertEqual(verdict["runtime_proof"]["resolved_model"], "vllm/DeepSeek-V4-Flash-262k")
            self.assertEqual(
                verdict["bindings"]["receipt_sha256"],
                supervisor.sha256_file(Path(result["evidence"]["validation_receipt_v2"])),
            )
            audit = supervisor.load_json(run_dir / "reviewer-audit-input.json")
            schema = supervisor.load_json(ROOT / "data" / "reviewer-audit-input.v1.schema.json")
            self.assertFalse(list(jsonschema_validator(schema).iter_errors(audit)))

    def test_review_records_reviewer_failure_without_claiming_success(self):
        with tempfile.TemporaryDirectory() as temp:
            workspace = Path(temp)
            artifact = workspace / "diagram.drawio"
            artifact.write_text(clean_diagram(), encoding="utf-8")
            with mock.patch.object(
                diagram_host.agent_runtime,
                "invoke_role",
                side_effect=supervisor.SupervisorError("isolated reviewer failed"),
            ):
                result = diagram_host.run_review(
                    artifact, workspace, sys.executable, run_id="review-failed"
                )
            self.assertEqual(result["status"], "findings")
            self.assertEqual(result["reviewer"]["status"], "failed")
            self.assertEqual(result["next_action"], "inspect_findings_before_any_repair")

    def test_review_preserves_model_proof_when_reviewer_json_breaks_schema(self):
        with tempfile.TemporaryDirectory() as temp:
            workspace = Path(temp)
            artifact = workspace / "diagram.drawio"
            artifact.write_text(clean_diagram(), encoding="utf-8")
            proof = {
                "verified": True,
                "system_model": "vllm/DeepSeek-V4-Flash-262k",
                "assistant_model": "vllm/DeepSeek-V4-Flash-262k",
                "stats_models": ["vllm/DeepSeek-V4-Flash-262k"],
            }
            failure = diagram_host.agent_runtime.RoleOutputContractError(
                "isolated reviewer output schema failed: candidate_sha256 is required",
                resolution={
                    "requested_model": "vllm/DeepSeek-V4-Flash-262k",
                    "resolved_model": "vllm/DeepSeek-V4-Flash-262k",
                    "resolution_mode": "isolated_cli",
                    "fallback_used": False,
                },
                runtime_metadata={"model_proof": proof},
                invalid_output_sha256="d" * 64,
            )
            with mock.patch.object(
                diagram_host.agent_runtime, "invoke_role", side_effect=failure
            ):
                result = diagram_host.run_review(
                    artifact, workspace, sys.executable, run_id="review-schema-failed"
                )

            reviewer = result["reviewer"]
            self.assertEqual(reviewer["status"], "failed")
            self.assertEqual(
                reviewer["resolved_model"], "vllm/DeepSeek-V4-Flash-262k"
            )
            self.assertTrue(reviewer["model_proof"]["verified"])
            self.assertEqual(reviewer["invalid_output_sha256"], "d" * 64)

    def test_review_rejects_artifact_outside_workspace(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            workspace = root / "project"
            workspace.mkdir()
            artifact = root / "outside.drawio"
            artifact.write_text(clean_diagram(), encoding="utf-8")
            with self.assertRaisesRegex(supervisor.SupervisorError, "inside the current workspace"):
                diagram_host.run_review(artifact, workspace, sys.executable)
            self.assertFalse((workspace / ".diagram-runs").exists())

    def test_qwen_extension_command_executes_host_before_model_prompt(self):
        prompt = (ROOT / "commands" / "drawio" / "review.md").read_text(encoding="utf-8")
        self.assertTrue(prompt.startswith("---\ndescription:"))
        self.assertIn("!{PYTHON=python3", prompt)
        self.assertIn("scripts/diagram_host.py", prompt)
        self.assertIn("DRAWIO_COMMAND_ARGS={{args}}", prompt)
        self.assertNotIn("--artifact {{args}}", prompt)
        self.assertNotIn('"$CLI" {{args}}', prompt)
        self.assertIn("Do not call any tools", prompt)
        self.assertIn("GIGACODE_EXTENSIONS_DIR", prompt)
        self.assertIn("GIGACODE_BIN", prompt)
        self.assertIn("PYTHON_BIN", prompt)
        self.assertNotIn("|| true", prompt)

    def test_cli_review_runs_end_to_end_with_gigacode_event_contract(self):
        with tempfile.TemporaryDirectory() as temp:
            workspace = Path(temp)
            artifact = workspace / "diagram with spaces.drawio"
            artifact.write_text(clean_diagram(), encoding="utf-8")
            cli = workspace / "fake-gigacode"
            cli.write_text(
                """#!/usr/bin/env python3
import json, sys
if '--help' in sys.argv:
    print('GigaCode --model --prompt --output-format --approval-mode --auth-type --extensions --system-prompt --max-session-turns --core-tools --allowed-mcp-server-names --exclude-tools')
    raise SystemExit(0)
if '--version' in sys.argv:
    print('26.5.17-test')
    raise SystemExit(0)
raw = sys.stdin.read()
payload = json.loads(raw)
model = payload['context']['requested_reviewer_model']
analysis = {
    'schema_version': 2,
    'role': 'reviewer',
    'status': 'ok',
    'analysis_id': 'real-adapter-test',
    'verdict': 'approve',
    'reviewed_at': '2026-07-20T12:00:00+00:00',
    'findings': [],
}
encoded = json.dumps(analysis)
events = [
    {'type': 'system', 'subtype': 'init', 'model': model, 'qwen_code_version': '0.13.1-test'},
    {'type': 'assistant', 'message': {'model': model, 'content': [{'type': 'text', 'text': encoded}]}},
    {'type': 'result', 'subtype': 'success', 'is_error': False, 'result': encoded, 'stats': {'models': {model: {'tokens': 1}}}},
]
print(json.dumps(events))
""",
                encoding="utf-8",
            )
            cli.chmod(0o700)

            completed = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPTS / "diagram_host.py"),
                    "review",
                    "--workspace",
                    str(workspace),
                    "--cli",
                    str(cli),
                    "--run-id",
                    "cli-e2e",
                ],
                text=True,
                capture_output=True,
                check=False,
                cwd=workspace,
                env={
                    **os.environ,
                    "DRAWIO_COMMAND_ARGS": '@"diagram with spaces.drawio"',
                },
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            result = json.loads(completed.stdout)
            self.assertEqual(result["status"], "passed")
            self.assertEqual(result["artifact"]["path"], str(artifact.resolve()))
            self.assertEqual(result["command_resolution"]["diagram_selection"], "explicit")
            self.assertEqual(result["reviewer"]["resolution_mode"], "isolated_cli")
            self.assertTrue(result["reviewer"]["model_proof"]["verified"])
            self.assertTrue(result["reviewer"]["binding_proof"]["verified"])
            self.assertEqual(result["reviewer"]["binding_proof"]["source"], "host-bound-reviewer-verdict-v2")
            analysis = supervisor.load_json(result["reviewer"]["analysis"])
            self.assertEqual(analysis["schema_version"], 2)
            self.assertEqual(analysis["analysis_id"], "real-adapter-test")
            verdict = supervisor.load_json(result["reviewer"]["output"])
            self.assertEqual(verdict["schema_version"], 2)
            self.assertEqual(verdict["analysis_id"], "real-adapter-test")
            self.assertEqual(verdict["runtime_proof"]["resolved_model"], "vllm/DeepSeek-V4-Flash-262k")
            self.assertEqual(
                verdict["bindings"]["receipt_sha256"],
                supervisor.sha256_file(Path(result["evidence"]["validation_receipt_v2"])),
            )
            improve = result["next_commands"]["improve"]
            self.assertEqual(improve, "/drawio:improve")
            explicit = result["next_commands"]["improve_explicit"]
            self.assertTrue(explicit.startswith("/drawio:improve --diagram "))
            improve_tokens = diagram_host.command_ux.qwen_command_tokens(
                explicit.removeprefix("/drawio:improve ")
            )
            self.assertEqual(improve_tokens[0], "--diagram")
            self.assertEqual(improve_tokens[1], str(artifact.resolve()))
            self.assertEqual(improve_tokens[2], "--request")
            manifest = [
                json.loads(line)
                for line in Path(result["evidence"]["manifest"]).read_text(encoding="utf-8").splitlines()
            ]
            self.assertIn("model_resolved", [event["event_type"] for event in manifest])
            self.assertIn("review_verdict", [event["event_type"] for event in manifest])
            selected, selection = diagram_host.command_ux.select_latest_run(workspace)
            self.assertEqual(Path(selected), Path(result["run_dir"]))
            self.assertEqual(selection, "latest_updated_run")
            trace = diagram_orchestrator.trace_run(result["run_id"], workspace)
            self.assertTrue(trace["valid"])
            self.assertEqual(trace["terminal_result"], "passed")
            self.assertEqual([role["role"] for role in trace["roles"]], ["reviewer"])
            self.assertTrue(trace["role_checks"][0]["binding_proof_valid"])
            trace_command = result["next_commands"]["trace"]
            self.assertEqual(trace_command, f"/drawio:trace --run {result['run_id']}")

    def test_all_qwen_commands_use_one_raw_argument_transport(self):
        for name in ("create", "improve", "review", "resume", "trace"):
            with self.subTest(name=name):
                prompt = (
                    ROOT / "commands" / "drawio" / f"{name}.md"
                ).read_text(encoding="utf-8")
                self.assertEqual(prompt.count("{{args}}"), 1)
                self.assertIn("DRAWIO_COMMAND_ARGS={{args}}", prompt)


def jsonschema_validator(schema):
    import jsonschema
    return jsonschema.Draft202012Validator(schema, format_checker=jsonschema.FormatChecker())


if __name__ == "__main__":
    unittest.main()
